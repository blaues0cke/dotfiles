import { connect }    from 'react-redux';
import React          from 'react';
import { StyleSheet } from 'react-native';
import Theme          from '../helper/Theme';

@connect(
    state => (
        {}
    ),
    dispatch => (
        {}
    )
)
class Component extends React.Component {

    styles = {};

    buildStyles (props) {
        if (!props) {
            props = this.props;
        }
    }

    constructor (props) {
        super(props);

        this.buildStyles();
    }

    componentWillReceiveProps (nextProps) {
        this.buildStyles(nextProps);
    }

    render () {
        return (
            null
        );
    }
}

const styles = StyleSheet.create({
});

Component.propTypes = {};

Component.defaultProps = {};

module.exports = Component;