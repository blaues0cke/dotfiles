import { connect }              from 'react-redux';
import NavigationOptionsBuilder from '../helper/NavigationOptionsBuilder';
import React                    from 'react';
import { StyleSheet }           from 'react-native';

@connect(
    (state) => (
        {}
    ),
    (dispatch) => (
        {}
    )
)
class Screen extends React.Component {

    static navigationOptions = ({ navigation, screenProps }) => {
        return NavigationOptionsBuilder('${NAME}Title', {
            tabBarIcon: 'hand-spock-o'
        });
    };

    render () {
        return (null);
    }
}

const styles = StyleSheet.create({});

module.exports = Screen;