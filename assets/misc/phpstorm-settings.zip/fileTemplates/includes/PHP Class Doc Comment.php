/**
 * Class ${NAME}
 *
 * @author Thomas Kekeisen <thomas@lulububu.de>
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 */
